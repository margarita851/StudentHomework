﻿using System.Collections.Generic;
using System.Text;

namespace CourseWorkSpace
{
    public class Galaxy    
    {
        public string Name { get; set; }

        public string Type { get; set; }

        public decimal Age { get; set; }

        public char AgeChar { get; set; }

        public List<Star> Stars { get; set; }

        public Galaxy(string name, string type, decimal age, char ageChar)
        {
            Name = name;
            Type = type;
            Age = age;
            AgeChar = ageChar;

            Stars = new List<Star>();
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Type: " + Type);
            sb.AppendLine("Age: " + Age + AgeChar);

            if (Stars.Count <= 0) return sb.ToString();

            sb.AppendLine("Stars:");
            Stars.ForEach(s => sb.Append(s));

            return sb.ToString();
        }
    }
}
