﻿using System.Collections.Generic;
using System.Text;

namespace CourseWorkSpace
{
    public class Star
    {
        public string Name { get; set; }

        public char StarClass { get; set; }

        public decimal Mass { get; set; }

        public decimal Size { get; set; }

        public long Temperature { get; set; }

        public decimal Luminosity { get; set; }

        public List<Planet> Planets;

        public Star(string name, decimal mass, decimal size, long temperature, decimal luminosity)
        {
            Name = name;
            Mass = mass;
            Size = size;
            Temperature = temperature;
            Luminosity = luminosity;

            Planets = new List<Planet>();

            SetStarClass();
        }

        private void SetStarClass()
        {
            if (Temperature >= 30_000
                && Luminosity >= 30_000
                && Mass >= 16M
                && Size >= 6.6M)
            {
                StarClass = 'O';
            }

            if (Temperature > 10_000 && Temperature < 30_000
                && Luminosity > 25 && Luminosity < 30_000
                && Mass > 2.1M && Mass < 16M
                && Size > 1.8M && Size < 6.6M)
            {
                StarClass = 'B';
            }

            if (Temperature > 7_500 && Temperature < 10_000
                && Luminosity > 5 && Luminosity < 25
                && Mass > 1.4M && Mass < 2.1M
                && Size > 1.4M && Size < 1.8M)
            {
                StarClass = 'A';
            }

            if (Temperature > 6_000 && Temperature < 7_500
                && Luminosity > 1.5M && Luminosity < 5
                && Mass > 1.04M && Mass < 1.4M
                && Size > 1.15M && Size < 1.4M)
            {
                StarClass = 'F';
            }

            if (Temperature > 5_200 && Temperature < 6_000
                && Luminosity > 0.6M && Luminosity < 1.5M
                && Mass > 0.8M && Mass < 1.04M
                && Size > 0.96M && Size < 1.15M)
            {
                StarClass = 'G';
            }

            if (Temperature > 3_700 && Temperature < 5_200
                && Luminosity > 0.08M && Luminosity < 0.6M
                && Mass > 0.45M && Mass < 0.8M
                && Size > 0.7M && Size < 0.96M)
            {
                StarClass = 'K';
            }

            if (Temperature > 2_400 
                && Temperature < 3_7200 
                && Luminosity <= 0.08M
                && Mass > 0.08M && Mass < 0.45M
                && Size <= 0.7M)
            {
                StarClass = 'M';
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            
            sb.AppendLine(@"    Name: " + Name);
            sb.AppendLine(@$"    Class: {StarClass} ({Mass}, {Size}, {Temperature}, {Luminosity:F2})");

            if (Planets.Count <= 0) return sb.ToString();

            sb.AppendLine("    Planets:");
            Planets.ForEach(p => sb.Append(p));

            return sb.ToString();
        }
    }
}
