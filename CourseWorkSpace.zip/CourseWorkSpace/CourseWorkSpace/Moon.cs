﻿using System.Text;

namespace CourseWorkSpace
{
    public class Moon
    {
        public string Name { get; set; }

        public Moon(string name)
        {
            Name = name;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(@$"{new string(' ', 20)}{Name}");
            return sb.ToString();
        }
    }
}
