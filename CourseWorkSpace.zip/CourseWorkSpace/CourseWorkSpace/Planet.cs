﻿using System.Collections.Generic;
using System.Text;

namespace CourseWorkSpace
{
    public class Planet
    {
        public string Name { get; set; }

        public string Type { get; set; }

        public bool IsHabitable { get; set; }

        public List<Moon> Moons { get; set; }
        
        public Planet(string name, string type, bool isHabitable)
        {
            Name = name;
            Type = type;
            IsHabitable = isHabitable;

            Moons = new List<Moon>();
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(@"          Name: " + Name);
            sb.AppendLine(@"          Type: " + Type);
            sb.AppendLine(@"          Support life: " + (IsHabitable ? "yes" : "no"));

            if (Moons.Count <= 0) return sb.ToString();
            sb.AppendLine(@"          Moons:");
            Moons.ForEach(p => sb.AppendLine(p.ToString()));

            return sb.ToString();
        }
    }
}
