﻿using System;
using System.Collections.Generic;

namespace CourseWorkSpace
{
    public class SpaceTests
    {
        public static List<Galaxy> galaxiesContainer = new List<Galaxy>();
        
        public static void Main()
        {
            //galaxiesContainer.Add(new Galaxy("Milkey Way", "elliptical", 13.2M,'B'));
            //galaxiesContainer[0].Stars.Add(new Star("Sun", 0.99M, 0.99M, 5778, 0.83M));
            //galaxiesContainer[0].Stars[0].Planets.Add(new Planet("Earth","terrestrial", true));
            //galaxiesContainer[0].Stars[0].Planets[0].Moons.Add(new Moon("Moon"));
            //Console.WriteLine(galaxiesContainer[0].ToString());
            
            string line = Console.ReadLine();
            //string line = "add moon [Earth] [Moon]";
            string[] commands = line.Split(' ');
            
            while (commands[0] != "exit")
            {
                switch (commands[0])
                {
                    case "add":

                        int closebracketIndex;

                        int openbracketIndex;

                        string[] objData;

                        string starName;

                        switch (commands[1])
                        {
                            case "galaxy":
                                openbracketIndex = line.IndexOf('[') + 1;
                                closebracketIndex = line.IndexOf(']');
                                
                                var objName = line.Substring(openbracketIndex, closebracketIndex - openbracketIndex);

                                objData = line
                                    .Substring(closebracketIndex + 1, line.Length - closebracketIndex - 1)
                                    .Split(' ');

                                var ageString = objData[2];
                                var age = decimal.Parse(ageString.Remove(ageString.Length - 1, 1));
                                var ageChar = ageString[^1];
                                galaxiesContainer.Add(new Galaxy(objName, objData[1], age, ageChar));
                                break;

                            case "star":
                                openbracketIndex = line.IndexOf('[');
                                closebracketIndex = line.IndexOf(']');

                                var galaxyName = line.Substring(openbracketIndex + 1, closebracketIndex - openbracketIndex - 1);

                                openbracketIndex = line.IndexOf(']', openbracketIndex) + 3;
                                closebracketIndex = line.LastIndexOf(']');

                                starName = line.Substring(openbracketIndex, closebracketIndex - openbracketIndex);

                                objData = line
                                    .Substring(closebracketIndex + 1, line.Length - closebracketIndex - 1)
                                    .Split(' ');

                                var star = new Star(
                                    starName,
                                    Convert.ToDecimal(objData[1]),
                                    Convert.ToDecimal(objData[2]),
                                    Convert.ToInt64(objData[3]),
                                    Convert.ToDecimal(objData[4]));

                                foreach (var galaxy in galaxiesContainer)
                                {
                                    if (galaxy.Name != galaxyName) continue;

                                    galaxy.Stars.Add(star);
                                    break;
                                }
                                break;

                            case "planet":
                                openbracketIndex = line.IndexOf('[');
                                closebracketIndex = line.IndexOf(']');

                                starName = line.Substring(openbracketIndex + 1, closebracketIndex - openbracketIndex - 1);

                                openbracketIndex = line.IndexOf(']', openbracketIndex) + 3;
                                closebracketIndex = line.LastIndexOf(']');

                                var planetName = line.Substring(openbracketIndex, closebracketIndex - openbracketIndex);

                                objData = line
                                    .Substring(closebracketIndex + 1, line.Length - closebracketIndex - 1)
                                    .Split(' ');

                                var newPlanet = new Planet(planetName, objData[1], objData[2] == "yes");

                                foreach (var g in galaxiesContainer)
                                {
                                    foreach (var s in g.Stars)
                                    {
                                        if (s.Name != starName)
                                            continue;

                                        s.Planets.Add(newPlanet);
                                        break;
                                    }
                                }

                                break;

                            case "moon":
                                openbracketIndex = line.IndexOf('[');
                                closebracketIndex = line.IndexOf(']');

                                planetName = line.Substring(openbracketIndex + 1, closebracketIndex - openbracketIndex - 1);

                                openbracketIndex = line.IndexOf(']', openbracketIndex) + 3;
                                closebracketIndex = line.LastIndexOf(']');

                                var moonName= line.Substring(openbracketIndex, closebracketIndex - openbracketIndex);

                                foreach (var g in galaxiesContainer)
                                {
                                    foreach (var s in g.Stars)
                                    {
                                        foreach (var p in s.Planets)
                                        {
                                            if (p.Name != planetName) continue;
                                            p.Moons.Add(new Moon(moonName));
                                            break;
                                        }
                                    }
                                }

                                break;
                        }
                        break;

                    case "list":
                        List<string> objNames = new List<string>();
                        var objectToList = commands[1];

                        switch (objectToList)
                        {
                            case "galaxies":

                                if (galaxiesContainer.Count == 0)
                                {
                                    Console.WriteLine("none");
                                    break;
                                }

                                Console.WriteLine("--- List of all researched galaxies ---");

                                foreach (var g in galaxiesContainer)
                                {
                                    Console.WriteLine(g.Name);
                                }

                                Console.WriteLine("--- End of galaxies list ---");
                                break;

                            case "stars":
                                
                                foreach (var g in galaxiesContainer)
                                {
                                    foreach (var s in g.Stars)
                                    {
                                        objNames.Add(s.Name);
                                    }
                                }

                                if (objNames.Count == 0)
                                {
                                    Console.WriteLine("none");
                                    break;
                                }

                                Console.WriteLine("--- List of all researched stars ---");

                                foreach (var s in objNames)
                                {
                                    Console.WriteLine(s);
                                }

                                Console.WriteLine("--- End of stars list ---");
                                break;

                            case "planets":
                                
                                foreach (var g in galaxiesContainer)
                                {
                                    foreach (var s in g.Stars)
                                    {
                                        foreach (var p in s.Planets)
                                        {
                                            objNames.Add(p.Name);
                                        }
                                    }
                                }

                                if (objNames.Count == 0)
                                {
                                    Console.WriteLine("none");
                                    break;
                                }

                                Console.WriteLine("--- List of all researched planets ---");

                                foreach (var p in objNames)
                                {
                                    Console.WriteLine(p);
                                }

                                Console.WriteLine("--- End of planets list ---");
                                break;

                            case "moon":
                                foreach (var g in galaxiesContainer)
                                {
                                    foreach (var s in g.Stars)
                                    {
                                        foreach (var p in s.Planets)
                                        {
                                            foreach (var m in p.Moons)
                                            {
                                                objNames.Add(m.Name);
                                            }
                                        }
                                    }
                                }

                                Console.WriteLine("--- List of all researched moon ---");

                                foreach (var m in objNames)
                                {
                                    Console.WriteLine(m);
                                }

                                Console.WriteLine("--- End of moon list ---");
                                break;
                        }

                        break;

                    case "stats":
                    {
                        Console.WriteLine("--- Stats ---");

                        Console.WriteLine("Galaxies: " + galaxiesContainer.Count);

                        int starsCount = 0;
                        foreach (var g in galaxiesContainer)
                        {
                            foreach (var s in g.Stars)
                            {
                                starsCount++;
                            }
                        }

                        Console.WriteLine("Stars: " + starsCount);

                        int planetsCount = 0;
                        foreach (var g in galaxiesContainer)
                        {
                            foreach (var s in g.Stars)
                            {
                                foreach (var p in s.Planets)
                                {
                                    planetsCount++;
                                }
                            }
                        }

                        Console.WriteLine("Planets: " + planetsCount);

                        int moonsCount = 0;
                        foreach (var g in galaxiesContainer)
                        {
                            foreach (var s in g.Stars)
                            {
                                foreach (var p in s.Planets)
                                {
                                    foreach (var m in p.Moons)
                                    {
                                        moonsCount++;
                                    }
                                }
                            }
                        }

                        Console.WriteLine("Moons: " + moonsCount);
                        Console.WriteLine("--- End of stats ---");
                        break;
                    }

                    case "print":
                        openbracketIndex = line.IndexOf('[') + 1;
                        closebracketIndex = line.IndexOf(']');

                        var galaxyToSearch = line.Substring(openbracketIndex, closebracketIndex - openbracketIndex);

                        Galaxy foundGalaxy = null;

                        foreach (var g in galaxiesContainer)
                        {
                            if (g.Name == galaxyToSearch)
                            {
                                foundGalaxy = g;
                                break;
                            }
                        }

                        if (foundGalaxy == null)
                        {
                            Console.WriteLine("none");
                        }
                        else
                        {
                            Console.WriteLine("--- Data for {0} galaxy ---", foundGalaxy.Name);
                            Console.Write(foundGalaxy);
                            Console.WriteLine("--- End of data for {0} galaxy ---", foundGalaxy.Name);
                        }
                        break;
                }

                line = Console.ReadLine();
                if (line != null) commands = line.Split(' ');
            }
        }
    }
}
